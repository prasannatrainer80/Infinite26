package com.infinite.bank.model;

import java.sql.Date;

public class Accounts {

  private int accountNo;
  private String firstName;
  private String lastName;
  private String city;
  private String state;
  private double amount;
  private String cheqFacil;
  private String accountType;
  private String status;
  private Date dateOfOpen;

  public int getAccountNo() {
    return accountNo;
  }

  public void setAccountNo(int accountNo) {
    this.accountNo = accountNo;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public double getAmount() {
    return amount;
  }

  public void setAmount(double amount) {
    this.amount = amount;
  }

  public String getCheqFacil() {
    return cheqFacil;
  }

  public void setCheqFacil(String cheqFacil) {
    this.cheqFacil = cheqFacil;
  }

  public String getAccountType() {
    return accountType;
  }

  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Date getDateOfOpen() {
    return dateOfOpen;
  }

  public void setDateOfOpen(Date dateOfOpen) {
    this.dateOfOpen = dateOfOpen;
  }

  public Accounts() {}
  public Accounts(int accountNo, String firstName, String lastName, String city, String state, double amount, String cheqFacil, String accountType, String status, Date dateOfOpen) {
    this.accountNo = accountNo;
    this.firstName = firstName;
    this.lastName = lastName;
    this.city = city;
    this.state = state;
    this.amount = amount;
    this.cheqFacil = cheqFacil;
    this.accountType = accountType;
    this.status = status;
    this.dateOfOpen = dateOfOpen;
  }

  @Override
  public String toString() {
    return "Accounts{" +
      "accountNo=" + accountNo +
      ", firstName='" + firstName + '\'' +
      ", lastName='" + lastName + '\'' +
      ", city='" + city + '\'' +
      ", state='" + state + '\'' +
      ", amount=" + amount +
      ", cheqFacil='" + cheqFacil + '\'' +
      ", accountType='" + accountType + '\'' +
      ", status='" + status + '\'' +
      ", dateOfOpen=" + dateOfOpen +
      '}';
  }
}

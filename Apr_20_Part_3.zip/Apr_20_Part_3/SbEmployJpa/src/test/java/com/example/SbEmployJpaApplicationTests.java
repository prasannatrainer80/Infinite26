package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbEmployJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.infinite.spr;

public class App {

  public static void main(String[] args) {
    System.out.println("Hello World!");
  }

}
